package com.java.srm.SocietyFinancialManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocietyFinancialManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocietyFinancialManagementApplication.class, args);
	}

}
